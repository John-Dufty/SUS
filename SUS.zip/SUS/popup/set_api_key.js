document.addEventListener('DOMContentLoaded', function() {
    var wrapper = document.getElementById('wrapper');
    var apiKeyInput = document.getElementById('api_key');
    var optionsButton = document.getElementById('options_button');
    var toggleVisibilityButton = document.getElementById('toggle_visibility');
    var setupButton = document.getElementById('setup');
    var userGuideButton = document.getElementById('setup_duplicate_1');
    var donateButton = document.getElementById('donate');
    var sampleText = document.getElementById('sampleText');

    chrome.storage.local.get('api_key', function(data) {
        if (data.api_key) {
            apiKeyInput.value = data.api_key;
        }
    });

optionsButton.addEventListener('click', function() {
        wrapper.style.display = wrapper.style.display === 'block' ? 'none' : 'block';
        optionsButton.classList.toggle('active');
        setupButton.classList.remove('active');
        userGuideButton.classList.remove('active');
        donateButton.classList.remove('active');
        sampleText.style.display = 'none';
    });

    setupButton.addEventListener('click', function() {
		sampleText.innerHTML = sampleText.innerHTML = 'Setup Guide:<br><br>1. Go to https://www.virustotal.com/gui/home/search and create an account.<br><br>2. Sign in to your account.<br><br>3. Click the link to your API key located in the top right corner of the page.<br><br>4. Copy your API key by clicking "Copy API key".<br><br>5. Locate the SUS extension logo under the extension menu and click on it.<br><br>6. Open the extension in a new tab.<br><br>7. Click "Options" in the extension.<br><br>8. Paste your API key in the form and click "Save".<br><br>9. Check out the User Guide for more information.';
        sampleText.style.display = sampleText.style.display === 'block' ? 'none' : 'block';
        setupButton.classList.toggle('active');
        userGuideButton.classList.remove('active');
        donateButton.classList.remove('active');
        optionsButton.classList.remove('active');
        wrapper.style.display = 'none';
    });

    userGuideButton.addEventListener('click', function() {
        sampleText.innerHTML = 'User Guide:<br><br>1. Begin by selecting the desired IP, hash, or URL ensuring that only the relevant text is highlighted. It\'s important to note that hashes must be in MD5 format and URLs should only contain the domain segment.<br><br>2. Once you\'ve highlighted the text, initiate the search by using the shortcut key combination, ALT+C. Wait until the text is no longer highlighted, indicating that the search has been completed.<br><br>3. The API response will be stored within the clipboard, allowing for quick and easy access to the information in JSON format. This information can be quickly pasted into a given ticket form to increase analyst efficiency.';
        sampleText.style.display = sampleText.style.display === 'block' ? 'none' : 'block';
        userGuideButton.classList.toggle('active');
        setupButton.classList.remove('active');
        donateButton.classList.remove('active');
        optionsButton.classList.remove('active');
        wrapper.style.display = 'none';
    });

    donateButton.addEventListener('click', function() {
        sampleText.innerHTML = 'Donation Links: <a href="buymeacoffee.com/johndufty1997" target="_blank" style="color: black;">Buy me a coffee</a> <br><br>Bitcoin: 12cQfKXZr3SWFbR1PeAqBH682EpHUMR7ft<br><br>This extension was made for free and open source to help Security Professionals expediently triage with OSINT tools. Any donations are appreciated but not essential.';
        sampleText.style.display = sampleText.style.display === 'block' ? 'none' : 'block';
        donateButton.classList.toggle('active');
        setupButton.classList.remove('active');
        userGuideButton.classList.remove('active');
        optionsButton.classList.remove('active');
        wrapper.style.display = 'none';
    });

    document.getElementById('save').addEventListener('click', function(event) {
        event.preventDefault();
    chrome.storage.local.set({ 'api_key': apiKeyInput.value }, function() {
        wrapper.style.display = 'none';
        optionsButton.classList.remove('active');
    });
});

toggleVisibilityButton.addEventListener('click', function() {
    apiKeyInput.type = apiKeyInput.type === 'password' ? 'text' : 'password';
    toggleVisibilityButton.classList.toggle('active');
});
});


